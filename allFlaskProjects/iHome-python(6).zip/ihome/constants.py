#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 常量

# 图片验证码redis中的有效期,单位：秒
IMAGE_CODE_REDIS_EXPIRES = 180

# 短信验证码redis中的有效期,单位：秒
SMS_CODE_REDIS_EXPIRES = 300

# 发送短信验证码的时间间隔, 单位：秒
SEND_SMS_CODE_INTERVAL = 60

# 登陆错误尝试次数
LOGIN_ERROR_MAX_TIMES = 5

# 登陆错误限制的时间，单位：秒
LOGIN_ERROR_FORBID_TIME = 600

# 七牛的域名
QINIU_URL_DOMAIN = 'http://pw5vkljsc.bkt.clouddn.com/'
