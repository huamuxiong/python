#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 常量

# 图片验证码redis中的有效期,单位：秒
IMAGE_CODE_REDIS_EXPIRES = 180

# 短信验证码redis中的有效期,单位：秒
SMS_CODE_REDIS_EXPIRES = 300
