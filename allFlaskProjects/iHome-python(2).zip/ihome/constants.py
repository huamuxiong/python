#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 常量

# redis中验证码的有效期,单位：秒
IMAGE_CODE_REDIS_EXPIRES = 180
