function getCookie(name) {
    var r = document.cookie.match("\\b" + name + "=([^;]*)\\b");
    return r ? r[1] : undefined;
}

$(document).ready(function(){
    $.get('/api/v1.0/areas', function (resp) {
        if (resp.errno == '0'){
            var areas = resp.data;
            // for(var i=0; i<areas.length; i++){
            //     var area = areas[i];
            //     // var option = '<option value="'+ area.aid +'">'+ area.aname +'</option>';
            //     $('#area-id').append('<option value="'+ area.aid +'">'+ area.aname +'</option>');
            // }
            var _html = template("areas-tmpl", {"areas": areas});
            $('#area-id').html(_html);
        }else{
            alert(resp.errmsg);
        }
    }, "json");
});